export class Loan{
    loanId:number;
    rateOfInterest:number;
    tenure:number;
    loanAmount:number;
    status:string;
    //Existing Loan Details
    existingLoanBank:string;
    existingLoanAmount:string;
    existingEmi:string;
    emi:number;
}