export class User{

    userId:number;
    name:string;
    email:string;
    mobile:string;
    password:string;
    confirmPassword:string;
    state:string;
    city:string;
    panNo:string;
    
    //Employment
    employmentType:string; 
    WorkExp:number;
    salary:number;
    profession:string;
    income:number;
    CompanyName:string;
    AnnualSalary:number;
    address:string;
    annualPension:string;

    //Loan 
    loanTenure:number;
    loanAmt:number;
    bankname:string;
    emiAmount:number;
    exloan:number;

}