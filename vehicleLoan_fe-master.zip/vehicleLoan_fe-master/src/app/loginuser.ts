export class loginUser{
    custId:number;
    password:String;
}