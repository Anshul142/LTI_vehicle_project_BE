export class Document {
    docId:number;
    panCard:any;
    aadharCard:any;
    paySlip:any;
}