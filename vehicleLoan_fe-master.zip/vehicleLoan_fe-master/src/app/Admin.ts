export class Admin{
    
    userName:string;
    userPassword:string;
}