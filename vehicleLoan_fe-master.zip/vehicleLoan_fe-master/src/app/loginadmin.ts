export class Loginadmin{
    
    adminId:number;
    userPassword:string;
}