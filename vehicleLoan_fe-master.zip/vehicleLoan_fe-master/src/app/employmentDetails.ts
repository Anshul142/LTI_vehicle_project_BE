export class EmploymentDetais{
    custId:number;
    empType:string; 
    workExp:number;
    salary:number;
    profession:string;
    companyName:string;
    companyAddress:string;
    companyCity:string;
    companyState:string;
    annualSal:number;
}