export class forgotpass {
    custId:number;
    email:string;
}