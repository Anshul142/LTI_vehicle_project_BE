export class UserDto{
    custFirstName:string;
    phone:string;
    email:string;
    password:string;
    confirmPassword:string;

}