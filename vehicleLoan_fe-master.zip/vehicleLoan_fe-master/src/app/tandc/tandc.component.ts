import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tandc',
  templateUrl: './tandc.component.html',
  styleUrls: ['./tandc.component.css']
})
export class TandcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
