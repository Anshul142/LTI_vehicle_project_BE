import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanscheme',
  templateUrl: './loanscheme.component.html',
  styleUrls: ['./loanscheme.component.css']
})
export class LoanschemeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
