export class resetpass{
    password:string;
    confirmPassword:string;
}